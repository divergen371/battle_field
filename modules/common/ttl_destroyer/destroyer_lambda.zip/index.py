import boto3
import json
import os
import logging
from datetime import datetime

# ロギング設定
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 環境変数
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')
SCENARIO_INFO = os.environ.get('SCENARIO_INFO')

def handler(event, context):
    """
    TTL期限切れ時に実行されるハンドラ関数
    リソースの破棄とSNS通知を行う
    """
    try:
        logger.info(f"TTL Destroyer起動: {event}")
        
        # シナリオ情報をJSONから取得
        scenario_info = json.loads(SCENARIO_INFO)
        scenario_name = scenario_info.get('scenario_name')
        
        # 初期メッセージ作成
        message = f"🕒 TTL期限切れ通知: シナリオ '{scenario_name}' のリソースを自動破棄します\n"
        message += f"作成時刻: {scenario_info.get('created_at')}\n"
        message += f"期限切れ時刻: {scenario_info.get('expires_at')}\n"
        
        # リソース破棄処理
        # 本番実装ではAWS SDKを使用して個別リソースを破棄
        # または外部プロセス（Terraform, AWS CLI）を実行
        # サンプル実装では通知のみ
        
        # SNS通知送信
        sns = boto3.client('sns')
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Subject=f"AWS Pentest Lab - シナリオ '{scenario_name}' 自動破棄通知",
            Message=message
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f"TTL期限切れ: シナリオ '{scenario_name}' のリソースを破棄しました",
                'scenario': scenario_info
            })
        }
    
    except Exception as e:
        logger.error(f"エラー発生: {str(e)}")
        
        # エラー通知
        if SNS_TOPIC_ARN:
            try:
                sns = boto3.client('sns')
                sns.publish(
                    TopicArn=SNS_TOPIC_ARN,
                    Subject="AWS Pentest Lab - TTL自動破棄エラー",
                    Message=f"TTL自動破棄処理中にエラーが発生しました。\nエラー: {str(e)}"
                )
            except Exception as sns_error:
                logger.error(f"SNS通知エラー: {str(sns_error)}")
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }
